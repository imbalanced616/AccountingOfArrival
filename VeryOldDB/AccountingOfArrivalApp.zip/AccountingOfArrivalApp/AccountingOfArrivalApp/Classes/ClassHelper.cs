﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AccountingOfArrivalApp.Classes
{
    internal class ClassHelper
    {
        public static Frame frmObj;

        public static AccountingOfArrivalEntities db = new AccountingOfArrivalEntities();
    }
}
