﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace AccountingOfArrivalApp.Classes
{
    public class User
    {
        public static User CurrentUser { get; set; }
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Patronymic { get; set; }
        public string TypeUser { get; set; }
        public User(int idUser, string login, string password, string surname, string name, string patronymic, int typeUser)
        {
            Id = idUser;
            Login = login;
            Password = password;
            Surname = surname;
            Name = name;
            Patronymic = patronymic;
            TypeUser = ClassHelper.db.TypesOfUsers.FirstOrDefault(x => x.idUserTypes == typeUser).NameType;
            CurrentUser = this;
        }
        public User(Users user)
        {
            Id = user.idUser;
            Login = user.Login;
            Password = user.Password;
            Surname = user.Surname;
            Name = user.Name;
            Patronymic = user.Patronymic;
            TypeUser = user.TypesOfUsers.NameType;
            CurrentUser = this;
        }
    }
}
