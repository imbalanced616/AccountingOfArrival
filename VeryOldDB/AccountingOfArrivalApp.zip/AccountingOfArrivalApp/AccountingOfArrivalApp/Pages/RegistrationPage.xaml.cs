﻿using AccountingOfArrivalApp.Classes;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AccountingOfArrivalApp.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegistrationPage.xaml
    /// </summary>
    public partial class RegistrationPage : Page
    {
        string imgLoc = "пусто";
        public RegistrationPage()
        {
            InitializeComponent();
        }

        private void BtnSingUp_Click(object sender, RoutedEventArgs e)
        {
            if (txbLogin.Text == "")
            {
                MessageBox.Show("Поле логин не заполнено!", "Ошибка полей ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (pbPassword.Password == "" || pbPassword2.Password == "")
            {
                MessageBox.Show("Поле пароль не заполнено!", "Ошибка полей ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (pbPassword.Password != pbPassword2.Password)
            {
                MessageBox.Show("Пароли не совпадают!", "Ошибка полей ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (ClassHelper.db.Users.FirstOrDefault(x => x.Login == txbLogin.Text) != null)
            {
                MessageBox.Show("Пользователь с таким логином уже существует!", "Ошибка полей ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
                txbLogin.Clear();
                return;
            }
            Users user = new Users() { Login = txbLogin.Text, Password = pbPassword.Password, Surname = txbSurname.Text, Name = txbName.Text, Patronymic = txbPatronymic.Text, idUserTypes = 3 };
            if (imgLoc != "пусто" && imgLoc != "очистить")
            {
                FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                user.Photo = br.ReadBytes((int)fs.Length);
            }
            if (imgLoc == "очистить") user.Photo = null;
            ClassHelper.db.Users.Add(user);
            try
            {
                ClassHelper.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            MessageBox.Show("Новый пользователь успешно зарегистрирован!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            User _ = new User(user);
            ClassHelper.frmObj.Navigate(new PageLobby());
        }

        private void BtnSingIn_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new LoginPage());
        }

        private void TxbSurname_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            txbSurname.Focus();
        }

        private void TxbName_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            txbName.Focus();
        }

        private void TxbPatronymic_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            txbPatronymic.Focus();
        }

        private void TxbLogin_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            txbLogin.Focus();
        }

        private void PbPassword_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            pbPassword.Focus();
        }

        private void PbPassword2_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            pbPassword2.Focus();
        }

        private void PbPassword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (((PasswordBox)sender).Password != "") txbPass.Visibility = Visibility.Hidden;
            else txbPass.Visibility = Visibility.Visible;
        }

        private void PbPassword2_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (((PasswordBox)sender).Password != "") txbPass2.Visibility = Visibility.Hidden;
            else txbPass2.Visibility = Visibility.Visible;
        }

        private void PhotoLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog { Filter = "Файлы изображений (*.png, *.jpg, *.jpeg, *.bmp)|*.png;*.jpg;*.jpeg;*.bmp|Все файлы (*.*)|*.*", Title = "Выберите фото/изображение" };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    photoUser.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void PhotoClear_Click(object sender, RoutedEventArgs e)
        {
            photoUser.Source = (ImageSource)FindResource("UnknownArtist");
            imgLoc = "очистить";
        }
    }
}
